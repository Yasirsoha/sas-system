<template>
    <div class="app-content content ">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper container-xxl p-0">
            <div class="content-header row">
                <div class="breadcrumb-wrapper">
                    <ol class="breadcrumb">
                        
                        <li class="breadcrumb-item active">Chat Bot
                        </li>
                    </ol>
                </div>
            </div>
            <div class="content-body">
               <div class="row card">
               <div class="col-md-6" style="border-right:1px solid grey">
               <div class="sidebar-content">
                        <br>
                        <!-- Sidebar header start -->
                        <div class="chat-fixed-search">
                            <div class="d-flex align-items-center w-100">
                                <div class="sidebar-profile-toggle">
                                    <div class="avatar avatar-border">
                                        <img src="public/app-assets/images/portrait/small/avatar-s-11.jpg" alt="user_avatar" height="42" width="42">
                                        <span class="avatar-status-online"></span>
                                    </div>
                                </div>
                                <div class="" style="margin-left:20px;width: 100%;">
                                    <input type="text" class="form-control" placeholder="Search or start a new chat" aria-label="Search..." aria-describedby="chat-search">
                               </div>
                            </div>
                        </div>
                        <!-- Sidebar header end -->
                        <hr>
                        <br>
                        <!-- Sidebar Users start -->
                        <div id="users-list" class="chat-user-list-wrapper list-group ps ps--active-y">
                            <h4 class="chat-list-title">My Contacts</h4>
                            <ul class="chat_ul">
                                <li>
                                   <a href="#" class="user_a">
                                    <div class="chat-info flex-grow-1">
                                        <h5 class="" style="width:70%;float:left"> <span class="avatar"><img src="public/app-assets/images/portrait/small/avatar-s-3.jpg" height="42" width="42" alt="Generic placeholder image">
                                        <span class="avatar-status-offline"></span>
                                    </span>Elizabeth Elliott</h5>
                                        <div style="float:right">
                                       <small class="float-end mb-25 chat-time">4:14 PM</small>
                                        <span class="badge bg-danger rounded-pill float-end">3</span></div>
                                    </div>
                                    </a>
                                </li>
                               
                               
                            </ul>
                          
                       

</div>
</div>

                        <!-- Sidebar Users end -->
                    </div>
               </div>
               <div class="col-md-6"></div>
               </div>

            </div>
        </div>
    </div>
</template>
<script>
export default {
    data() {
        return {

        }
    },
    mounted() {
        console.log('reports')
    }
}

</script>
<style scoped>
.chat_ul>li>a:hover,.user_a:hover{
    cursor: pointer;
    background: #f8f8f8;
}
chat_ul>li{
    text-decoration:none;
}

</style>
