<template>
   
    <!-- BEGIN: Main Menu-->
    <div  class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
        <div class="navbar-header">
            <ul class="nav navbar-nav flex-row">
                <li class="nav-item me-auto">
                <router-link class="navbar-brand" to="/"><span class="brand-logo">
                    <img v-bind:src="`public/images/${session_detail.company_logo}`" class="me-75" height="40" width="40" /> 
                            </span>
                        <h2 class="brand-text" style="padding-left:5px; font-size: 18px;
  width: 130px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;">{{session_detail.company_name}}</h2>
                    </router-link></li>
                <li class="nav-item nav-toggle"><a style="margin-top: 35px;" class="nav-link modern-nav-toggle pe-0" data-bs-toggle="collapse"><i class="d-block d-xl-none text-primary toggle-icon font-medium-4" data-feather="x"></i><i class="d-none d-xl-block collapse-toggle-icon font-medium-4  text-primary" data-feather="disc" data-ticon="disc"></i></a></li>
            </ul>
        </div>
        <div class="shadow-bottom"></div>
        <div class="main-menu-content">
         <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">

                <li class=" nav-item"><a class="d-flex align-items-center" ><i class="fa-solid fa-house-user"></i><span class="menu-title text-truncate" data-i18n="Dashboards" style="padding-top: 10px;">Dashboards</span><span class="badge badge-light-warning rounded-pill ms-auto me-1"></span></a>
                    <ul class="menu-content">
                      <li v-if="session_detail.hr_read=='true'&&session_detail.company_hr_status=='true'">
                            <router-link to="/recruitment/recDashboard" class="d-flex align-items-center">
                                <i data-feather="circle"></i>
                                <span class="menu-item text-truncate" data-i18n="Analytics">Rec. Dashboards</span>
                            </router-link>
                        </li>
                        <li v-if="session_detail.hr_read=='true'&&session_detail.company_hr_status=='true'"">
                        <router-link to="/hr/dashboard" class="d-flex align-items-center" ><i class="fa-regular fa-circle"></i><span class="menu-item text-truncate" data-i18n="Analytics">HR Dashboard</span></router-link>
                        </li>
                        <li v-if="session_detail.payroll_read=='true'&&session_detail.company_payroll_plan=='true'">
                        <router-link to="/" class="d-flex align-items-center" ><i class="fa-regular fa-circle"></i><span class="menu-item text-truncate" >Payroll Dashboard</span></router-link>
                        </li>
                       
                    </ul>
                </li>
                <li v-if="session_detail.hr_write=='true'&&session_detail.company_hr_status=='true'" class=" navigation-header"><span>Human Resource Module</span><i data-feather="more-horizontal"></i>
                </li>
                <li class=" nav-item" v-if="session_detail.hr_write=='true'&&session_detail.company_hr_status=='true'">
                    <a class="d-flex align-items-center" >
                   <i class="fa-solid fa-user"></i>
                        <span class="menu-title text-truncate" >Recruitment</span>
                    </a>
                    <ul class="menu-content">
                        <li>
                            <router-link class="d-flex align-items-center" to="/recruitment/jobs">
                                <i class="fa-regular fa-circle"></i>
                                <span class="menu-item text-truncate" >Job openings</span>
                            </router-link></li>
                            <li>
                            <router-link class="d-flex align-items-center" to="/recruitment/candidates">
                               <i class="fa-regular fa-circle"></i>
                                <span class="menu-item text-truncate" >Candidates</span>
                            </router-link></li>
                             <li>
                            <router-link class="d-flex align-items-center" to="/recruitment/interviews">
                               <i class="fa-regular fa-circle"></i>
                                <span class="menu-item text-truncate">Interviews</span>
                            </router-link></li>
                          
                      
                    </ul>
                </li>
                <li v-if="session_detail.hr_write=='true'&&session_detail.company_hr_status=='true'"  class=" nav-item"><a class="d-flex align-items-center" ><i class="fa-solid fa-file"></i><span class="menu-title text-truncate">HRMS</span></a>
                    <ul class="menu-content">
                        <li><router-link class="d-flex align-items-center" to="/hr/employees_detail"><i class="fa-regular fa-circle"></i><span class="menu-item text-truncate" data-i18n="List">Employees Detail</span></router-link>
                        </li>
                        <li><router-link to="/hr/warning_detail" class="d-flex align-items-center" ><i class="fa-regular fa-circle"></i><span class="menu-item text-truncate">Warning Detail</span></router-link>
                        </li>
                        <li><router-link to="/hr/leaves_dashbaord" class="d-flex align-items-center" ><i class="fa-regular fa-circle"></i><span class="menu-item text-truncate">Leaves Detail</span></router-link>
                        </li>
                        <li><router-link to="/hr/attendance/dashboard" class="d-flex align-items-center" ><i class="fa-regular fa-circle"></i><span class="menu-item text-truncate" >Attendance</span></router-link>
                        </li>
                        <li><router-link to="/hr/reports" class="d-flex align-items-center" ><i class="fa-regular fa-circle"></i><span class="menu-item text-truncate">Reports</span></router-link>
                        </li>
                        <li v-if="session_detail.hr_superadmin=='true'"><router-link to="/hr/configuration" class="d-flex align-items-center" ><i class="fa-regular fa-circle"></i><span class="menu-item text-truncate">HR Controller</span></router-link>
                        </li>
                    </ul>
                </li>
               <li v-if="session_detail.payroll_write=='true'&&session_detail.company_payroll_plan=='true'" class="nav-item">
                    <a class="d-flex align-items-center">
                        <i class="fa-solid fa-building-columns"></i><span class="menu-title text-truncate" data-i18n="Invoice">PayRoll</span>
                    </a>
                    <ul class="menu-content">
                        <li>
                            <router-link class="d-flex align-items-center" to="/payroll/salary_generation">
                                <i class="fa-regular fa-circle"></i>
                                <span class="menu-item text-truncate" data-i18n="List">Salaries</span>
                            </router-link>
                        </li>
                        <li>
                            <router-link class="d-flex align-items-center" to="/payroll/loans">
                                <i class="fa-regular fa-circle"></i>
                                <span class="menu-item text-truncate" data-i18n="List">Loan & Advance</span>
                            </router-link>
                        </li>
                        <li>
                            <router-link class="d-flex align-items-center" to="/payroll/arrears">
                                <i class="fa-regular fa-circle"></i>
                                <span class="menu-item text-truncate">Arrears & Bonuses</span>
                            </router-link>
                        </li>
                    </ul>
                </li>

                 <li v-if="session_detail.hr_superadmin=='true' && session_detail.company_hr_status=='true'" class=" navigation-header"><span data-i18n="">Roles & Permissions</span><i data-feather="more-horizontal"></i>
                </li>
                <li  v-if="session_detail.hr_superadmin=='true' && session_detail.company_hr_status=='true'"  class=" nav-item"><a class="d-flex align-items-center" ><i class="fa-solid fa-gear"></i><span class="menu-title text-truncate" data-i18n="Settings">Settings</span></a>
                    <ul class="menu-content">
                        <li><router-link  class="d-flex align-items-center" to="/settings/users"><i class="fa-regular fa-circle"></i><span class="menu-item text-truncate" data-i18n="List">Users Detail</span></router-link>
                        </li>
                        <li><router-link  class="d-flex align-items-center" to="/settings/location_detail"><i class="fa-regular fa-circle"></i><span class="menu-item text-truncate" data-i18n="List">Locations Detail</span></router-link>
                        </li>
                        <li><router-link  class="d-flex align-items-center" to="/settings/designation_detail"><i class="fa-regular fa-circle"></i><span class="menu-item text-truncate" data-i18n="List">Designation Detail</span></router-link>
                        <li><router-link  class="d-flex align-items-center" to="/settings/department_detail"><i class="fa-regular fa-circle"></i><span class="menu-item text-truncate" data-i18n="List">Departments Detail</span></router-link>
                        </li>
                        <li><router-link  class="d-flex align-items-center" to="/settings/activity_log"><i class="fa-regular fa-circle"></i><span class="menu-item text-truncate" data-i18n="List">Activity Logs</span></router-link>
                        </li>
                        
                        
                    </ul>
                </li>


             
             </ul>

        </div>
    </div>
    <!-- END: Main Menu-->
</template>

<script>
    export default {
     data() {
        return {
      session_detail:{ },
      
        }
        },
        mounted() {
          
           axios.get('./session_check')
            .then((response) => this.session_detail = response.data)
            .catch((error) => console.log(error));
            console.log('Footer')
        }
    }
</script>
<style>
.menu-dark{
    background-color: #283046;
}
</style>