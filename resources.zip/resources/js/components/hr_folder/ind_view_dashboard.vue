<template>
    <div>
        <div class="app-content content ">
            <div class="content-overlay"></div>
            <div class="header-navbar-shadow"></div>
            <div class="content-wrapper container-xxl p-0">
                <div class="content-header row">
                    <div class="breadcrumb-wrapper">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item active">
                                Employee Dashboard
                            </li>
                        </ol>
                    </div>
                </div>
                <div class="content-body">
                    <div class="row match-height">
                        <!-- Statistics Card -->
                        <div class="col-xl-8 full_div col-md-6 col-12">
                            <div class="card card-statistics">
                                <div class="card-header">
                                    <h4 class="card-title">Current Month Attendance</h4>
                                    <router-link to="/hr/team_leaves" class="role-edit-modal" style="text-decoration:none; color: #0d6efd; margin-left:35%;"> <small class="fw-bolder">Team Leaves</small></router-link>
                                    <router-link to="/hr/team_attendance" class="role-edit-modal" style="text-decoration:none;color: #0d6efd;"> <small class="fw-bolder">Team Attendance</small></router-link>
                                </div>
                                <div class="card-body statistics-body" style="padding-top: 5px !important; padding-bottom: 10px !important;">
                                    <div class="row">
                                        <div class="col-xl-3 col-sm-6 col-12 mb-2 mb-xl-0">
                                            <div class="d-flex flex-row">
                                                <div class="avatar bg-light-info me-2">
                                                    <div class="avatar-content">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user avatar-icon"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                                                    </div>
                                                </div>
                                                <div class="my-auto">
                                                    <h4 class="fw-bolder mb-0">{{ct_att.totalDays}}</h4>
                                                    <p class="card-text font-small-3 mb-0">Total Days</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-sm-6 col-12 mb-2 mb-xl-0">
                                            <div class="d-flex flex-row">
                                                <div class="avatar bg-light-primary me-2">
                                                    <div class="avatar-content">
                                                        <i class="fa-solid fa-check"></i>
                                                    </div>
                                                </div>
                                                <div class="my-auto">
                                                    <h4 class="fw-bolder mb-0">{{ct_att.present}}</h4>
                                                    <p class="card-text font-small-3 mb-0">Present</p>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-sm-6 col-12 mb-2 mb-sm-0">
                                            <div class="d-flex flex-row">
                                                <div class="avatar bg-light-danger me-2">
                                                    <div class="avatar-content">
                                                        <i class="fa-solid fa-xmark"></i>
                                                    </div>
                                                </div>
                                                <div class="my-auto">
                                                    <h4 class="fw-bolder mb-0">{{ct_att.absent}}</h4>
                                                    <p class="card-text font-small-3 mb-0">Absent</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-sm-6 col-12">
                                            <div class="d-flex flex-row">
                                                <div class="avatar bg-light-success me-2">
                                                    <div class="avatar-content">
                                                        <i class="fa-solid fa-litecoin-sign"></i>
                                                    </div>
                                                </div>
                                                <div class="my-auto">
                                                    <h4 class="fw-bolder mb-0">{{ct_att.late}}</h4>
                                                    <p class="card-text font-small-3 mb-0">Late</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--/ Statistics Card -->
                        <!-- Medal Card -->
                        <div class="col-xl-4 col-md-6 col-12">
                            <div class="row match-height">
                                <!-- Bar Chart - Orders -->
                                <div class="col-lg-6 col-md-3 col-6">
                                    <div class="card">
                                        <div class="card-body pb-50" style="position: relative;">
                                            <h6>
                                                Apply For
                                            </h6>
                                            <h3 class="fw-bolder mb-1" style="padding-bottom: 15px;">Leaves</h3>
                                            <a @click="fetch_emp_leave()" data-bs-toggle="modal" data-bs-target="#addNewCard" style="width:100%;" class="btn btn-primary waves-effect waves-float waves-light">Apply Now</a>
                                        </div>
                                    </div>
                                </div>
                                <!--/ Bar Chart - Orders -->
                                <!-- Line Chart - Profit -->
                                <div class="col-lg-6 col-md-3 col-6">
                                    <div class="card card-tiny-line-stats">
                                        <div class="card-body pb-50" style="position: relative;">
                                            <h6>View Your</h6>
                                            <h3 class="fw-bolder mb-1" style="padding-bottom: 15px;">Profile</h3>
                                            <router-link style="width:100%;" to="/hr/emp_detail" class="btn btn-primary waves-effect waves-float waves-light">Click Here</router-link>
                                        </div>

                                    </div>
                                </div>
                                <!--/ Line Chart - Profit -->
                            </div>
                        </div>
                        <!--/ Medal Card -->
                    </div>
                    <div class="row match-height">
                        <div class="col-lg-4 col-md-4 col-12">
                            <div class="card shadow-none border cursor-pointer">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <img src="public/app-assets/images/icons/annual.png" alt="google drive" height="38" />
                                        <a data-bs-toggle="modal" data-bs-target="#annual_leaves" class="role-edit-modal" style="text-decoration:none;color:#0d6efd"> <small class="fw-bolder">View Detail</small></a>
                                    </div>
                                    <div class="my-1">
                                        <h5>Annual Leaves</h5>
                                    </div>
                                    <div class="d-flex justify-content-between mb-50">
                                        <span class="text-truncate">{{leaves_dtl.ttl_annual - leaves_dtl.rem_annual}} Used</span>
                                        <small class="text-muted">Out of {{leaves_dtl.ttl_annual}}</small>
                                    </div>
                                    <b-progress :max="`${leaves_dtl.ttl_annual}`">
                                        <b-progress-bar :value="`${(leaves_dtl.ttl_annual - leaves_dtl.rem_annual)}`" :label="`${((1 - (leaves_dtl.rem_annual / leaves_dtl.ttl_annual)) * 100).toFixed(0)}%`"></b-progress-bar>
                                    </b-progress>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-12">
                            <div class="card shadow-none border cursor-pointer">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <img src="public/app-assets/images/icons/fever.png" alt="google drive" height="38" />
                                        <a data-bs-toggle="modal" data-bs-target="#sick_leaves" class="role-edit-modal" style="text-decoration:none;color:#0d6efd"> <small class="fw-bolder">View Detail</small></a>
                                    </div>
                                    <div class="my-1">
                                        <h5>Sick Leaves</h5>
                                    </div>
                                    <div class="d-flex justify-content-between mb-50">
                                        <span class="text-truncate">{{leaves_dtl.ttl_sick - leaves_dtl.rem_sick}}  Used</span>
                                        <small class="text-muted">Out of {{leaves_dtl.ttl_sick}}</small>
                                    </div>
                                    <b-progress :max="`${leaves_dtl.ttl_sick}`">
                                        <b-progress-bar :value="`${(leaves_dtl.ttl_sick - leaves_dtl.rem_sick)}`" :label="`${((1 - (leaves_dtl.rem_sick / leaves_dtl.ttl_sick)) * 100).toFixed(0)}%`"></b-progress-bar>
                                    </b-progress>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-12">
                            <div class="card shadow-none border cursor-pointer">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <img src="public/app-assets/images/icons/casual.png" alt="google drive" height="38" />
                                        <a data-bs-toggle="modal" data-bs-target="#casual_leaves" class="role-edit-modal" style="text-decoration:none;color:#0d6efd"> <small class="fw-bolder">View Detail</small></a>
                                    </div>
                                    <div class="my-1">
                                        <h5>Casual Leaves</h5>
                                    </div>
                                    <div class="d-flex justify-content-between mb-50">
                                        <span class="text-truncate">{{leaves_dtl.ttl_casual - leaves_dtl.rem_casual}} Used</span>
                                        <small class="text-muted">Out of {{leaves_dtl.ttl_casual}}</small>
                                    </div>
                                    <b-progress :max="`${leaves_dtl.ttl_casual}`">
                                        <b-progress-bar :value="`${(leaves_dtl.ttl_casual - leaves_dtl.rem_casual)}`" :label="`${((1 - (leaves_dtl.rem_casual / leaves_dtl.ttl_casual)) * 100).toFixed(0)}%`"></b-progress-bar>
                                    </b-progress>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row match-height">
                        <!-- Company Table Card -->
                        <div class="col-lg-12 col-12">
                            <div class="card card-company-table">
                                <div class="card-body p-0">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Day</th>
                                                    <th>Check In</th>
                                                    <th>Check Out</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr v-for="attendance1 in attendance">
                                                    <td>{{attendance1.ATTDate}}</td>
                                                    <td>Monday</td>
                                                    <td>{{attendance1.CheckIN}}</td>
                                                    <td>{{attendance1.CheckOut}}</td>
                                                    <td>On Time</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--/ Company Table Card -->
                        <!-- Developer Meetup Card -->
                        <div class="col-lg-4 col-md-6 col-12">
                        </div>
                        <!--/ Developer Meetup Card -->
                    </div>
                </div>
            </div>
        </div>
        <!-- View annual leave modal -->
        <div class="modal fade" id="annual_leaves" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered modal-edit-user">
                <div class="modal-content">
                    <div class="modal-header bg-transparent">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body pb-5 px-sm-5 pt-50">
                        <div class="text-center mb-2">
                            <h1 class="mb-1">Your Annual Leave Detail</h1>
                        </div>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Leave Type</th>
                                        <th>Reason</th>
                                        <th>Applied by</th>
                                        <th>Manager status</th>
                                        <th>HR status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="this_m_lvs1 in this_m_lvs" v-if="this_m_lvs1.Leavetype=='Annual Leave'">
                                        <td>22-05-2022</td>
                                        <td>{{this_m_lvs1.Leavetype}}</td>
                                        <td>{{this_m_lvs1.Reason}}</td>
                                        <td>{{this_m_lvs1.AppliedBy}}</td>
                                        <td v-if="this_m_lvs1.ManagerApproval=='1'">Approved</td>
                                        <td v-else>Not Approved</td>
                                        <td v-if="this_m_lvs1.HRApproval=='1'">Approved</td>
                                        <td v-else>Not Approved</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/ View annual leave modal -->
        <!-- View Sick leave modal -->
        <div class="modal fade" id="sick_leaves" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered modal-edit-user">
                <div class="modal-content">
                    <div class="modal-header bg-transparent">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body pb-5 px-sm-5 pt-50">
                        <div class="text-center mb-2">
                            <h1 class="mb-1">Your Annual Leave Detail</h1>
                        </div>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Leave Type</th>
                                        <th>Reason</th>
                                        <th>Applied by</th>
                                        <th>Manager status</th>
                                        <th>HR status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="this_m_lvs1 in this_m_lvs" v-if="this_m_lvs1.Leavetype=='Sick Leave'">
                                        <td>22-05-2022</td>
                                        <td>{{this_m_lvs1.Leavetype}}</td>
                                        <td>{{this_m_lvs1.Reason}}</td>
                                        <td>{{this_m_lvs1.AppliedBy}}</td>
                                        <td v-if="this_m_lvs1.ManagerApproval=='1'">Approved</td>
                                        <td v-else>Not Approved</td>
                                        <td v-if="this_m_lvs1.HRApproval=='1'">Approved</td>
                                        <td v-else>Not Approved</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/ View sick leave modal -->
        <!-- View Casual leave modal -->
        <div class="modal fade" id="casual_leaves" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered modal-edit-user">
                <div class="modal-content">
                    <div class="modal-header bg-transparent">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body pb-5 px-sm-5 pt-50">
                        <div class="text-center mb-2">
                            <h1 class="mb-1">Your Annual Leave Detail</h1>
                        </div>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Leave Type</th>
                                        <th>Reason</th>
                                        <th>Applied by</th>
                                        <th>Manager status</th>
                                        <th>HR status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="this_m_lvs1 in this_m_lvs" v-if="this_m_lvs1.Leavetype=='Casual Leave'">
                                        <td>22-05-2022</td>
                                        <td>{{this_m_lvs1.Leavetype}}</td>
                                        <td>{{this_m_lvs1.Reason}}</td>
                                        <td>{{this_m_lvs1.AppliedBy}}</td>
                                        <td v-if="this_m_lvs1.ManagerApproval=='1'">Approved</td>
                                        <td v-else>Not Approved</td>
                                        <td v-if="this_m_lvs1.HRApproval=='1'">Approved</td>
                                        <td v-else>Not Approved</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/ View Casual leave modal -->
        <!-- Apply for leave modal  -->
        <div class="modal fade" id="addNewCard" tabindex="-1" aria-labelledby="addNewCardTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-transparent">
                        <h3 class="text-center mb-1" id="addNewCardTitle">Apply For Leave</h3>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body px-sm-5 mx-50 pb-5">
                        <!-- form -->
                        <form id="addNewCardValidation" class="row gy-1 gx-2 mt-75" onsubmit="return false">
                            <div class="col-12">
                                <table class="table" v-if="this.isLvEmpty != 'Empty'">
                                    <thead>
                                        <tr>
                                            <th>Type</th>
                                            <th>Granted</th>
                                            <th>Used</th>
                                            <th>Balance</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-for="leavesblnc1 in leavesblnc">
                                            <td>{{leavesblnc1.LeaveType}}</td>
                                            <td>{{leavesblnc1.TotalLeave}}</td>
                                            <td>{{leavesblnc1.TotalLeave - leavesblnc1.RemainingLeave}}</td>
                                            <td>{{leavesblnc1.RemainingLeave}}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-12">
                                <label class="form-label" for="modalAddCardNumber">Leave Type</label>
                                <select v-model="type" class="form-control">
                                    <option value="">Select Type</option>
                                    <option value="Annual">Annual</option>
                                    <option value="Casual">Casual</option>
                                    <option value="Sick">Sick</option>
                                    <option value="CPL">CPL</option>
                                </select>
                                <span style="color: #DB4437; font-size: 11px;" v-if="type==''">{{type_error}}</span>
                            </div>
                            <div class="col-12 col-sm-12 mb-1">
                                <label class="form-label" for="basicSelect">Select Duration Type</label>
                                <div class="row demo-inline-spacing" style="padding-left: 5%;">
                                    <div class="col-md-5 form-check form-check-inline" style="margin-top:0px">
                                        <input class="form-check-input" type="radio" v-model="days" name="inlineRadioOptions" id="inlineRadio1" value="One Day" checked="">
                                        <label class="form-check-label" for="inlineRadio1">One Day</label>
                                    </div>
                                    <div class=" col-md-5 form-check form-check-inline" style="margin-top:0px">
                                        <input class="form-check-input" type="radio" v-model="days" name="inlineRadioOptions" id="inlineRadio2" value="Multiple Days">
                                        <label class="form-check-label" for="inlineRadio2">Multiple Days</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-02">
                                <label class="form-label" for="modalAddCardName">Date</label>
                                <label class="form-label" v-if="this.days=='Multiple Days'" for="modalAddCardName"> From</label>
                                <input type="date" v-model="d_from" id="modalAddCardName" class="form-control" />
                                <span style="color: #DB4437; font-size: 11px;" v-if="d_from==''">{{d_from_error}}</span>
                            </div>
                            <div class="col-md-02" v-if="this.days=='Multiple Days'">
                                <label class="form-label" for="modalAddCardName">Date To</label>
                                <input type="date" v-model="d_to" id="modalAddCardName" class="form-control" />
                            </div>
                            <div class="col-md-12">
                                <label class="form-label" for="modalAddCardName">Reason</label>
                                <input type="text" v-model="reason" id="modalAddCardName" class="form-control" placeholder="Reason of leave" />
                                <span style="color: #DB4437; font-size: 11px;" v-if="reason==''">{{reason_error}}</span>
                            </div>
                            <div class="col-12 text-center" style="margin-top:6%">
                                <button type="submit" @click="leave_request()" class="btn btn-primary me-1 mt-1" data-bs-dismiss="modal" aria-label="Close">Submit</button>
                                <button type="reset" class="btn btn-outline-secondary mt-1" data-bs-dismiss="modal" aria-label="Close">
                                    Cancel
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--/ Apply for leave modal  -->
    </div>
</template>

<script>
    export default {
        data: function () {
            return {
                days: 'One Day',
                attendance: {},
                ct_att: {},
                this_m_lvs: {},
                leaves_dtl: {},
                leavesblnc: {},

                type: '',
                isLvEmpty: 'Empty',
                d_from: '',
                d_to: '',
                reason: '',
                type_error: '',
                d_from_error: '',
                reason_error: '',
                ct_att: '',

                value: 1,
                max: 14,
                max_cas: '',
                max_sick: '',
                max_annual: '',
            }
        },
        methods: {
            leave_request()//Add ind Leave
            {
                if (this.type == '' || this.d_from == '' || this.reason == '') {
                    if (this.type == '') {
                        this.type_error = 'Selest leave type';
                    }
                    else {
                        this.type_error = '';
                    }

                    if (this.d_from == '') {
                        this.d_from_error = 'Select date';
                    }
                    else {
                        this.d_from_error = '';
                    }

                    if (this.reason == '') {
                        this.reason_error = 'Type reason';
                    }
                    else {
                        this.reason_error = '';
                    }
                    this.$toastr.e("Leave not applied", "Important Fields Missing!")

                }
                else {
                    if (this.days == 'One Day') {
                        this.d_to = null;
                    }
                    else {
                        this.d_to = this.d_to;
                    }
                    axios.post('./leave_request_rt', {
                        type: this.type,
                        d_from: this.d_from,
                        d_to: this.d_to,
                        reason: this.reason,
                        days: this.days,
                    })
                        .then(data => {
                            if (data.data == 'Leave Applied Successfully!') {
                                this.$toastr.s("Leave Applied successfully!", "Congratulations!");

                                axios.get('this_user_attendence')  //Get current session attendance of logged in employee
                                    .then(data => this.attendance = data.data)
                                    .catch(error => { });

                                this.type = '';
                                this.d_from = '';
                                this.d_to = '';
                                this.reason = '';
                            }
                        })
                }
            }
        },
        mounted() {
            axios.get('selected_emp_leaves_blnc/' + 0)
                .then(data => {
                    this.leavesblnc = data.data;
                    if (this.leavesblnc == '') {
                        this.isLvEmpty = "Empty";
                    }
                    else {
                        this.isLvEmpty = "Not empty";
                    }
                })
                .catch(error => { });

            axios.get('this_user_attendence')  //Get current session attendance of logged in employee
                .then(data => this.attendance = data.data)
                .catch(error => { });

            axios.get('m_att_dtl_ct') //Count current month attendance details
                .then(data => this.ct_att = data.data)
                .catch(error => { });

            axios.get('leaves_dtl') //Count leaves detail
                .then(data => this.leaves_dtl = data.data)
                .catch(error => { });

            axios.get('m_lv_dtl_rt') //Get leaves details
                .then(data => this.this_m_lvs = data.data)
                .catch(error => { });

        }
    }
</script>

<style>
    @media(max-width:576px){
    .full_div{
    width:100% !important;
    }
    }

</style>
