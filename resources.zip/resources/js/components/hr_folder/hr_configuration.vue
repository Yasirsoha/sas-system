<template>
    <div v-if="user_access.hr_write=='true'">
        <!-- BEGIN: Content-->
        <div class="app-content content ">
            <div class="content-overlay"></div>
            <div class="header-navbar-shadow"></div>
            <div class="content-wrapper container-xxl p-0">
                <div class="content-header row">
                    <div class="breadcrumb-wrapper">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <router-link to="/hr/dashboard" style="text-decoration: none;">Dashboard</router-link>
                            </li>
                            <li class="breadcrumb-item active">HR Configuration
                            </li>
                        </ol>
                    </div>
                </div>
                <div class="content-body">
                    <section class="app-user-view-account">
                        <div class="row">
                            <!-- User Sidebar -->
                            <div class="col-xl-6 col-lg-6 col-md-6 order-1 order-md-0">
                                <div class="card">
                                    <div class="card-header">
                                        <h2 style="font-size:24px" class="card-title">Add New Session</h2>
                                    </div>
                                    <div class="card-body">
                                        <form class="form form-vertical">
                                            <div class="row">
                                                <div class="col-12" style="margin-top:20px">
                                                    <div class="mb-1">
                                                        <label class="form-label" for="first-name-vertical">Session Detail</label>
                                                        <div class="table-responsive">
                                                            <table class="table table-flush-spacing">
                                                                <tbody>
                                                                    <tr>
                                                                        <td class="text-nowrap">
                                                                            <label style="width:100%">Current</label>
                                                                            <div style="margin-bottom:10px" class="form-check form-check-info form-switch">
                                                                                <input style="width: 50px;" type="checkbox" v-model="c_session" class="form-check-input" id="customSwitch3">
                                                                            </div>
                                                                        </td>
                                                                        <td class="text-nowrap fw-bolder">
                                                                            <input type="date" v-model="session_start" class="form-control" style="    margin-top: 20px;" />
                                                                        </td>
                                                                        <td class="text-nowrap fw-bolder">
                                                                            <input type="date" v-model="session_end" class="form-control" style="    margin-top: 20px;" />
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <button type="button" @click="submit_session()" class="btn btn-primary me-1 waves-effect waves-float waves-light">Submit</button>
                                                    <button type="reset" class="btn btn-outline-secondary waves-effect">Reset</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!--/ User Sidebar -->
                            <div class="col-xl-6 col-lg-6 col-md-6 order-1 order-md-0">
                                <!-- User Card -->
                                <div class="card">
                                    <div class="card-body">
                                        <div style="margin-bottom:20px;" class="d-flex justify-content-between align-items-center header-actions mx-2 row mt-75">
                                            <div class="col-sm-12 col-lg-12 ps-xl-75 ps-0">
                                                <div class="dt-action-buttons d-flex align-items-center justify-content-center justify-content-lg-end flex-lg-nowrap flex-wrap">
                                                    <div class="me-1">
                                                        <div id="DataTables_Table_0_filter" class="dataTables_filter" style="margin-top:5px"><label>
                                                                <input autocomplete="off" class="form-control" style="" placeholder="Search By Location" />
                                                            </label></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <section id="accordion-with-border">
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div id="accordionWrapa50" role="tablist" aria-multiselectable="true">
                                                        <div class="card">
                                                            <div class="card-header">
                                                                <h4 class="card-title">Session Details</h4>
                                                            </div>
                                                            <div class="card-body">
                                                                <div class="table-responsive" style="overflow-x: initial !important;">
                                                                    <table class="table">
                                                                        <thead>
                                                                            <tr>
                                                                                <th>Name</th>
                                                                                <th>Start</th>
                                                                                <th>End</th>
                                                                                <th></th>
                                                                                <th></th>
                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            <tr class="odd" v-for="adsdata1 in adsdata.data">
                                                                                <td>{{adsdata1.SessionName}}</td>
                                                                                <td>{{adsdata1.StartDate}}</td>
                                                                <td>{{adsdata1.EndDate}}</td>
                                            <td>
                                            <span class="badge bg-gradient-success" v-if="adsdata1.CurrentSession==1">Running</span>
                                            <span v-if="user_access.hr_overall=='true'">
                                            <a v-if="adsdata1.AttClosedPayrollStart=='Open'" @click="fetch_session_id(adsdata1.SessionID)" data-bs-toggle="modal" data-bs-target="#hireinterview"> 
                                               <span class="badge bg-gradient-info" style="cursor: pointer;">Open</span>
                                                </a>
                                                  <a v-else> 
                                                    <span class="badge bg-gradient-warning" style="cursor: pointer;" >Closed</span>
                                                      </a>
                                            </span>
                                            <span v-else>
                                                    <a v-if="adsdata1.AttClosedPayrollStart=='Open'" > 
                                               <span class="badge bg-gradient-info" style="cursor: pointer;">Open</span>
                                                </a>
                                                  <a v-else> 
                                                    <span class="badge bg-gradient-warning" style="cursor: pointer;" >Closed</span>
                                                      </a>
                                            </span>
                                             
                                                                                </td>
                                                                                <td>




                                                                                <a @click="delete_session(adsdata1.SessionID)" class="me-25">
                                                                                        <i style="color:#d42f2f" class="fa-solid fa-trash"></i>
                                                                                    </a></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </div>
                                                                <div style="text-align:center;padding-top:20px">
                                                                    <pagination :data="adsdata" @pagination-change-page="getResult"></pagination>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                                <!-- /User Card -->
                            </div>
                        </div>
                    </section>
                    <section class="app-user-view-account">
                        <div class="row">
                            <!-- User Sidebar -->
                            <div class="col-xl-6 col-lg-6 col-md-6 order-1 order-md-0">
                                <div class="card">
                                    <div class="card-body">
                                        <section id="accordion-with-border">
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div id="accordionWrapa50" role="tablist" aria-multiselectable="true">
                                                        <div class="card">
                                                            <div class="card-header">
                                                                <h4 class="card-title">Holidays Detail</h4>
                                                                <a data-bs-toggle="modal" data-bs-target="#addNewCard" class="btn btn-outline-primary waves-effect" type="button">Apply Holiday</a>
                                                            </div>
                                                            <div class="card-body">
                                                                <div class="table-responsive" style="overflow-x: initial !important;">
                                                                    <table class="table">
                                                                        <thead>
                                                                            <tr>
                                                                                <th>Holiday Name</th>
                                                                                <th>Start</th>
                                                                                <th>End</th>
                                                                                <th>No.of days</th>
                                                                                <th></th>
                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            <tr class="odd" v-for="holiday_data1 in holiday_data.data">
                                                                                <td>{{holiday_data1.HolidayName}}</td>
                                                                                <td>{{holiday_data1.holidaystartDate}}</td>
                                                                                <td>{{holiday_data1.HolidayEndDate}}</td>
                                                                                <td>{{holiday_data1.NoOfDays}}</td>
                                                                                <td><a @click="delete_holiday(holiday_data1.HolidayID)" class="me-25">
                                                                                        <i style="color:#d42f2f" class="fa-solid fa-trash"></i>
                                                                                    </a></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </div>
                                                                <div style="text-align:center;padding-top:20px">
                                                                    <pagination :data="adsdata" @pagination-change-page="getResult2"></pagination>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                            </div>
                            <!--/ User Sidebar -->
                            <div class="col-xl-6 col-lg-6 col-md-6 order-1 order-md-0">
                                <!-- User Card -->
                                <div class="card">
                                    <div class="card-body">
                                        <section id="accordion-with-border">
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div id="accordionWrapa50" role="tablist" aria-multiselectable="true">
                                                        <div class="card">
                                                            <div class="card-header">
                                                                <h4 class="card-title">Leave Types</h4>
                                                                <a data-bs-toggle="modal" data-bs-target="#leavetype" class="btn btn-outline-primary waves-effect" type="button">Add Leave Type</a>
                                                            </div>
                                                            <div class="card-body">
                                                                <div class="table-responsive" style="overflow-x: initial !important;">
                                                                    <table class="table">
                                                                        <thead>
                                                                            <tr>
                                                                                <th>Leave Type</th>
                                                                                <th></th>
                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            <tr class="odd" v-for="l_types1 in l_types.data">
                                                                                <td>{{l_types1.LeaveType}}</td>
                                                                                <td><a @click="delete_leave(l_types1.LeaveID)" class="me-25">
                                                                                        <i style="color:#d42f2f" class="fa-solid fa-trash"></i>
                                                                                    </a></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </div>
                                                                <div style="text-align:center;padding-top:20px">
                                                                    <pagination :data="adsdata" @pagination-change-page="getResult3"></pagination>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                                <!-- /User Card -->
                            </div>
                            <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 order-1 order-md-0">
                                <!-- User Card -->
                                <div class="card">
                                    <div class="card-body">
                                        <section id="accordion-with-border">
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div id="accordionWrapa50" role="tablist" aria-multiselectable="true">
                                                        <div class="card">
                                                            <div class="card-header">
                                                                <h4 class="card-title">HR Configuration</h4>
                                                               
                                                            </div>
                                                            <div class="card-body">
                                                               
                                                              <div class="row">
                                         <div class="col-12 col-sm-3 mb-1">
                                                    <label class="form-label" for="accountFirstName">Gratuty Start From (Days)</label>
                                                    <label style="color: #d93025">*</label>
                                                    <input type="number"  class="form-control" id="accountFirstName" v-model="gratuty_start">
                                                  
                                         </div>
                                                <div class="col-12 col-sm-3 mb-1">
                                                    <label class="form-label" for="accountFirstName">Max Loan Allowed (Times of salary)</label>
                                                    <label style="color: #d93025">*</label>
                                                    <input type="number"  class="form-control" id="accountFirstName" v-model="max_loan">
                                                  
                                         </div>
                                         <div class="col-12 col-sm-3 mb-1">
                                                    <label class="form-label" for="accountFirstName">Minutes Per Deducation</label>
                                                    <label style="color: #d93025">*</label>
                                                    <input type="number"  class="form-control" id="accountFirstName" v-model="days_deduction">
                                                  
                                         </div>
                                         <div class="col-12 col-sm-3 mb-1">
                                                    <label class="form-label" for="accountFirstName">Maximium Installment</label>
                                                    <label style="color: #d93025">*</label>
                                                    <input type="number"class="form-control" id="accountFirstName" v-model="max_installment">
                                                  
                                         </div>
                                         <div class="col-12 col-sm-3 mb-1">
                                                    <label class="form-label" for="accountFirstName">Annual Leaves (after probation end)</label>
                                                    <label style="color: #d93025">*</label>
                                                    <input type="number"class="form-control" id="accountFirstName" v-model="annual_leaves">
                                                  
                                         </div>
                                         <div class="col-12 col-sm-3 mb-1">
                                                    <label class="form-label" for="accountFirstName">Sick Leaves (per fiscal year)</label>
                                                    <label style="color: #d93025">*</label>
                                                    <input type="number" class="form-control" id="accountFirstName" v-model="sick_leaves">
                                                  
                                         </div>

                                         <div class="col-12 col-sm-3 mb-1">
                                                    <label class="form-label" for="accountFirstName">Casual Leaves (per fiscal year)</label>
                                                    <label style="color: #d93025">*</label>
                                                    <input type="number" class="form-control" id="accountFirstName" v-model="casual_start">
                                                  
                                         </div>
                                         <div class="col-12 col-sm-3 mb-1" style="padding-top: 25px;">
                                         <button type="submit" style="width:100%" @click="submit_configuration()" class="btn btn-primary me-1 mt-1">Update</button>            
                                                  
                                         </div>
                                                
                                         





                                                              </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                                <!-- /User Card -->
                            </div>
                             <div class="col-xl-12 col-lg-12 col-md-12 order-1 order-md-0">
                                <!-- User Card -->
                                <div class="card">
                                    <div class="card-body">
                                        <section id="accordion-with-border">
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div id="accordionWrapa50" role="tablist" aria-multiselectable="true">
                                                        <div class="card">
                                                            <div class="card-header">
                                                                <h4 class="card-title">Fine Detail</h4>
                                                                <a data-bs-toggle="modal" data-bs-target="#finemodal" class="btn btn-outline-primary waves-effect" type="button">Add New Fine</a>
                                                            </div>
                                                            <div class="card-body">
                                                                <div class="table-responsive" style="overflow-x: initial !important;">
                                                                    <table class="table">
                                                                        <thead>
                                                                            <tr>
                                                                                <th>Emp.Code</th>
                                                                                 <th>Name</th>
                                                                                  <th>Fine Session</th>
                                                                                   <th>Fine Date</th>
                                                                                    <th>Amount</th>
                                                                                     <th>Remarks</th>
                                                                                      <th>Issued</th>
                                                                                      <th></th>
                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            <tr class="odd" v-for="finedetail1 in finedetail.data">
                                                                            <td>{{finedetail1.EmployeeCode}}</td>
                                                                                <td>{{finedetail1.Name}}</td>
                                                                               <td>{{finedetail1.FineSession}}</td>
                                                                                <td>{{finedetail1.FineAmount}}</td>
                                                                                 <td>{{finedetail1.FineDate}}</td>
                                                                                  <td>{{finedetail1.Remarks}}</td>
                                                                                  <td>{{finedetail1.CreatedBy}}</td>
                                                           <td><a @click="delete_fine(finedetail1.FineId)" class="me-25">
                                                                                        <i style="color:#d42f2f" class="fa-solid fa-trash"></i>
                                                                                    </a></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </div>
                                                                <div style="text-align:center;padding-top:20px">
                                                                    <pagination :data="adsdata" @pagination-change-page="getResult4"></pagination>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                                <!-- /User Card -->
                            </div>
                            </div>

                            <div class="modal fade" id="addNewCard" tabindex="-1" aria-labelledby="addNewCardTitle" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <div class="modal-header bg-transparent">
                                            <h3 class="text-center mb-1" id="addNewCardTitle">Apply Holiday</h3>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body px-sm-5 mx-50 pb-5">
                                            <form id="addNewCardValidation" class="row gy-1 gx-2 mt-75" onsubmit="return false">
                                                <div class="col-12">
                                                    <label class="form-label" for="modalAddCardName">Holiday Name</label>
                                                    <input type="text" v-model="h_holiday_name" class="form-control">
                                                </div>
                                                <div class="col-md-12">
                                                    <label class="form-label" for="modalAddCardName">Date From</label>
                                                    <input v-model="h_date_from" type="date" id="modalAddCardName" class="form-control" />
                                                </div>
                                                <div class="col-12 col-sm-12 mb-1">
                                                    <label class="form-label" for="basicSelect">Select Days</label>
                                                    <div class="row demo-inline-spacing" style="padding-left: 5%;">
                                                        <div class="col-md-5 form-check form-check-inline" style="margin-top:0px">
                                                            <input class="form-check-input" type="radio" v-model="days" name="inlineRadioOptions" id="inlineRadio1" value="One Day" checked="">
                                                            <label class="form-check-label" for="inlineRadio1">One Day</label>
                                                        </div>
                                                        <div class=" col-md-5 form-check form-check-inline" style="margin-top:0px">
                                                            <input class="form-check-input" type="radio" v-model="days" name="inlineRadioOptions" id="inlineRadio2" value="Multiple Days">
                                                            <label class="form-check-label" for="inlineRadio2">Multiple Days</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div v-if="this.days=='Multiple Days'" class="col-md-12">
                                                    <label class="form-label" for="modalAddCardName">Date To</label>
                                                    <input v-model="h_date_to" type="date" id="modalAddCardName" class="form-control" />
                                                </div>
                                                <div class="col-md-12">
                                                    <label class="form-label" for="modalAddCardName">Description</label>
                                                    <input v-model="h_description" type="text" id="modalAddCardName" class="form-control" />
                                                </div>
                                                <div class="col-12 text-center">
                                                    <button type="submit" @click="submit_holiday()" class="btn btn-primary me-1 mt-1" data-bs-dismiss="modal" aria-label="Close">Submit</button>
                                                    <button type="reset" class="btn btn-outline-secondary mt-1" data-bs-dismiss="modal" aria-label="Close">
                                                        Cancel
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
        <div class="modal fade" id="leavetype" tabindex="-1" aria-labelledby="addNewCardTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-transparent">
                        <h3 class="text-center mb-1" id="addNewCardTitle">Add Leave Type</h3>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body px-sm-5 mx-50 pb-5">
                        <form id="addNewCardValidation" class="row gy-1 gx-2 mt-75" onsubmit="return false">
                            <div class="col-12">
                                <label class="form-label" for="modalAddCardName">Type Name</label>
                                <input type="text" v-model="l_type" class="form-control">
                            </div>
                            <div class="col-12 text-center">
                                <button type="submit" @click="submit_leave()" class="btn btn-primary me-1 mt-1" data-bs-dismiss="modal" aria-label="Close">Submit</button>
                                <button type="reset" class="btn btn-outline-secondary mt-1" data-bs-dismiss="modal" aria-label="Close">
                                    Cancel
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="hireinterview" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-lg modal-dialog-centered modal-edit-user">
                            np
                            <div class="modal-content">
                                <div class="modal-header bg-transparent">
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body pb-5 px-sm-5 pt-50">
                                    <div class="text-center mb-2">
                                        <h1 class="fw-bolder">Confirmation</h1>
                                        <h5>Do you want to Close this session and move employees attendance to payroll?</h5>
                                        <div class="text-center" style="text-align:center">
                                            <button type="button" @click="update_session_payroll()" class="btn btn-primary waves-effect waves-float waves-light" data-bs-dismiss="modal" aria-label="Close">Yes</button>
                                            <button type="submit" class="btn btn-outline-primary waves-effect" data-bs-dismiss="modal" aria-label="Close">No</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        <div class="modal fade" id="finemodal" tabindex="-1" aria-labelledby="addNewCardTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-transparent">
                        <h3 class="text-center mb-1" id="addNewCardTitle">Issued Fine To Employee</h3>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body px-sm-5 mx-50 pb-5">
                        <form id="addNewCardValidation" class="row gy-1 gx-2 mt-75" onsubmit="return false">
                            <div class="col-12">
                                <label class="form-label" for="modalAddCardName">Employee Id</label>
                                <select v-model="emp_emp_id" class="form-control">
                                    <option value="">Select Employee</option>
                                    <option v-for='find_emp1 in find_emp' :value='find_emp1.EmployeeID'>{{ find_emp1.EmployeeCode }}-{{ find_emp1.Name }}</option>
                                </select>
                               
                            </div>
                             <div  class="col-md-12">
                                <label class="form-label" for="modalAddCardName">Fine Amount</label>
                                <input v-model="emp_amount" type="number" id="modalAddCardName" class="form-control" />
                            </div>
                            <div class="col-md-12">
                                <label class="form-label" for="modalAddCardName">Reason</label>
                                <input v-model="emp_reason" type="text" id="modalAddCardName" class="form-control" />
                               
                            </div>
                            <div class="col-12 text-center">
                                <button type="submit" @click="submit_fine()" class="btn btn-primary me-1 mt-1" data-bs-dismiss="modal" aria-label="Close">Submit</button>
                                <button type="reset" class="btn btn-outline-secondary mt-1" data-bs-dismiss="modal" aria-label="Close">
                                    Cancel
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    data() {
        return {
         user_access:{},
            session_start: '',
            session_end: '',
            c_session: '',
            adsdata: {

            },
            days: 'One Day',
            h_holiday_name: '',
            h_date_from: '',
            h_date_to: '',
            h_description: '',
            holiday_data: {},
            l_type: '',
            l_types: {},

            gratuty_start:'',
            max_loan:'',
            days_deduction:'',
            max_installment:'',
            annual_leaves:'',
            sick_leaves:'',
            casual_start:'',
            fetch_sessoin_id:'',

            finedetail:{ },
            find_emp:{ },
            emp_emp_id:'',
            emp_amount:'',
            emp_reason:'',

        }
    },

    methods: {
    fetch_session_id(id){
    this.fetch_sessoin_id=id;
    },
    update_session_payroll(){
    axios.get('update_payroll_status/' + this.fetch_sessoin_id)
                .then(response => {
               
                    this.$toastr.s("Attendance Closed and proceed in Payroll Section!", "Information");
                   
                })
                this.$router.go(0);
                },
    submit_configuration(){
      axios.post('submit_config', {
                   gratuty_start: this.gratuty_start,
            max_loan: this. max_loan,
            days_deduction: this.days_deduction,
            max_installment: this.max_installment,
            annual_leaves: this.annual_leaves,
            sick_leaves: this.sick_leaves,
            casual_start: this.casual_start,
                })
                .then(data => {
                    this.$toastr.s("Updated Configuration Successfully!", "Congratulations");
                })
    },
        submit_leave() {
            axios.post('submit_l', {
                    l_type: this.l_type
                })
                .then(data => {
                    this.l_types = data.data;
                    this.$toastr.s("Add Leave Type Successfully!", "Congratulations");
                })
        },
        submit_holiday() {
            axios.post('submit_holidays', {
                    h_holiday_name: this.h_holiday_name,
                    h_date_from: this.h_date_from,
                    h_date_to: this.h_date_to,
                    h_description: this.h_description,
                })
                .then(data => {
                    this.holiday_data = data.data;
                    this.$toastr.s("Updated Holiday Successfully!", "Holiday");
                })

        },
        delete_leave(id) {
            axios.get('delete_leave_type/' + id)
                .then(response => {
                    this.$toastr.s("Delete Record Successfully!", "Deleted");
                    this.l_types = response.data

                })
                .catch(error => {});

        },
        delete_holiday(id) {
            axios.get('delete_holiday/' + id)
                .then(response => {
                    this.$toastr.s("Delete Record Successfully!", "Deleted");
                    this.holiday_data = response.data

                })
                .catch(error => {});

        },

        delete_session(id) {
            axios.get('delete_session/' + id)
                .then(response => {
                    this.$toastr.s("Delete Record Successfully!", "Deleted");
                    this.adsdata = response.data

                })
                .catch(error => {});

        },
        delete_fine(id) {
            axios.get('delete_fine/' + id)
                .then(response => {
                    this.$toastr.s("Delete Record Successfully!", "Deleted");
                    this.finedetail = response.data

                })
                .catch(error => {});

        },
        submit_session() {

            axios.post('submit_session', {
                    session_start: this.session_start,
                    session_end: this.session_end,
                    c_session: this.c_session,
                })
                .then(data => {
                    if (data.data == 'NotSubmitted') {
                        this.$toastr.e("Session Name Already Exists!", "Change Roster Name");
                    } else {
                        this.$toastr.s("Session Created Successfully!", "Congratulations");
                        this.adsdata = data.data;
                    }


                })
                .catch(error => {});



        },
        getResult(page = 1) {

            axios.get('session_detail/?page=' + page)
                .then(response => this.adsdata = response.data)
                .catch(error => {});
        },
        getResult2(page = 1) {

            axios.get('holiday_detail/?page=' + page)
                .then(response => this.holiday_data = response.data)
                .catch(error => {});
        },
        getResult3(page = 1) {

            axios.get('view_leave_type/?page=' + page)
                .then(response => this.l_types = response.data)
                .catch(error => {});
        },
         getResult4(page = 1) {

            axios.get('view_fine_detail/?page=' + page)
                .then(response => this.finedetail = response.data)
                .catch(error => {});
        },
        submit_fine(){
            
             axios.post('submit_fine', {
                   emp_emp_id:this.emp_emp_id,
                    emp_amount:this.emp_amount,
                    emp_reason:this.emp_reason,
                })
                .then(data => {
                this.finedetail = data.data
                this.$toastr.s("Applied Fine Successfully!", "Congratulations");
                })
                .catch(error => {});
        },

    },

    mounted() {
    axios.get('./fetch_user_hr_roles')
                .then(response => this.user_access = response.data)
        this.getResult();
        this.getResult2();
        this.getResult3();
        this.getResult4();
         axios.get('view_hr_configuration')
                .then(response => {
                 this.gratuty_start= response.data[0].GratutyStart;
            this.max_loan= response.data[0].MaxLoan;
            this.days_deduction= response.data[0].MinutesDeduction;
            this.max_installment= response.data[0].MaxInstallment;
            this.annual_leaves= response.data[0].AnnualLeaves;
            this.sick_leaves= response.data[0].SickLeaves;
            this.casual_start= response.data[0].CasualLeaves;

                })
                .catch(error => {});
                  axios.get('find_emp_id')
                .then(data => this.find_emp = data.data)
                .catch(error => { });
    }
}

</script>
